import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';
import 'mdb-react-ui-kit/dist/css/mdb.min.css';
import { Provider } from 'react-redux';
import CustomStore from './CustomStore.jsx'

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(

  <Provider store = {CustomStore}>

    <React.StrictMode>
       <h1>Testing </h1>
    </React.StrictMode>
    
  </Provider>

);

