import { combineReducers } from "redux";
import users from './users.jsx'
 
export default combineReducers({
     users
 })