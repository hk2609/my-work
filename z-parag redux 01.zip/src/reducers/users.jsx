
let initialState = {}
const userreducers = (users = initialState, action) => {
    const { type, payload } = action
    switch (type) {
        case RETRIVE_ALL_USERS:
            console.log("RETRIVE_ALL_USERS")
        return {...payload}
    
        default:
           return users
    }
}
export const selectUsers = (state) =>state.users